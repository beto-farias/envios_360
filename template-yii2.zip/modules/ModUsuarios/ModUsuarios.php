<?php

namespace app\modules\ModUsuarios;

/**
 * modUsuarios module definition class
 */
class ModUsuarios extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'app\modules\ModUsuarios\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
