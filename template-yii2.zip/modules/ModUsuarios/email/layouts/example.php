<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<h1>Mensaje con formato</h1>
<?php
echo $test;?>
</body>
</html>
